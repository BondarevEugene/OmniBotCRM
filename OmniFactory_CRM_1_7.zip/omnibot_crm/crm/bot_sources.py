"""Bot-specific encrypted source settings with legacy environment fallback."""
from sqlalchemy import select

from .bot_settings import setting_value
from .models import Bot


def food_porn_source(db, config):
    bot = db.scalar(select(Bot).where(Bot.key == 'food_porn'))
    if bot:
        url = setting_value(db, bot.id, 'source_database_url', config)
        if url:
            return url
    return config.food_porn_source_database_url
