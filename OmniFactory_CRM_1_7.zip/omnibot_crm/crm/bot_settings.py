"""Typed per-bot settings with encryption for sensitive values."""
import json
import re
from datetime import date
from decimal import Decimal, InvalidOperation

from cryptography.fernet import Fernet, InvalidToken
from fastapi import HTTPException
from sqlalchemy import select

from .models import BotSetting

KEY_PATTERN = re.compile(r'^[a-z][a-z0-9_]{0,79}$')
KINDS = {'text', 'multiline', 'integer', 'number', 'boolean', 'json', 'list',
         'url', 'email', 'date', 'secret'}


def normalize_setting(key, kind, value):
    if not KEY_PATTERN.fullmatch(key) or kind not in KINDS or len(value) > 64000:
        raise HTTPException(422, 'Invalid setting name, type or size')
    if key == 'ingest_secret' and (kind != 'secret' or len(value) < 24):
        raise HTTPException(422, 'The ingest secret needs at least 24 characters')
    if (key in ('telegram_token', 'source_database_url') or key.endswith(('_secret', '_token', '_password', '_api_key', '_private_key'))) and kind != 'secret':
        raise HTTPException(422, 'Sensitive settings must be encrypted')
    if kind == 'number':
        try:
            number = Decimal(value)
            if not number.is_finite():
                raise ValueError()
            value = str(number)
        except (InvalidOperation, ValueError):
            raise HTTPException(422, 'Invalid number') from None
    elif kind == 'integer':
        try:
            value = str(int(value))
        except (TypeError, ValueError):
            raise HTTPException(422, 'Invalid integer') from None
    elif kind == 'boolean':
        if value.lower() not in ('true', 'false'):
            raise HTTPException(422, 'Use true or false')
        value = value.lower()
    elif kind == 'json':
        try:
            json.loads(value)
        except ValueError:
            raise HTTPException(422, 'Invalid JSON') from None
    elif kind == 'list':
        try:
            if not isinstance(json.loads(value), list):
                raise ValueError()
        except ValueError:
            raise HTTPException(422, 'Expected a JSON array') from None
    elif kind == 'url':
        if not value.startswith('https://') or len(value) > 2000:
            raise HTTPException(422, 'Use an HTTPS URL')
    elif kind == 'email':
        if len(value) > 255 or '@' not in value or not value.split('@')[-1].count('.'):
            raise HTTPException(422, 'Invalid email address')
    elif kind == 'date':
        try:
            date.fromisoformat(value)
        except ValueError:
            raise HTTPException(422, 'Use YYYY-MM-DD') from None
    return value


def encrypt(value, key):
    if not key:
        raise HTTPException(409, 'Set CRM_ENCRYPTION_KEY before saving secret settings')
    return Fernet(key.encode()).encrypt(value.encode()).decode()


def decrypt(value, key):
    if not key:
        raise RuntimeError('CRM_ENCRYPTION_KEY is missing')
    try:
        return Fernet(key.encode()).decrypt(value.encode()).decode()
    except InvalidToken:
        raise RuntimeError('The configured encryption key cannot decrypt stored bot settings') from None


def setting_value(db, bot_id, name, config):
    row = db.scalar(select(BotSetting).where(BotSetting.bot_id == bot_id, BotSetting.key == name))
    if row is None or not row.is_configured:
        return None
    return decrypt(row.value, config.encryption_key) if row.kind == 'secret' else row.value


def runtime_settings(db, bot_id, config):
    """Return bot-owned settings only to an authenticated bot process."""
    rows = db.scalars(select(BotSetting).where(BotSetting.bot_id == bot_id,
                                               BotSetting.is_configured.is_(True))).all()
    def unpack(row):
        if row.kind == 'secret':
            return decrypt(row.value, config.encryption_key)
        if row.kind == 'boolean':
            return row.value == 'true'
        if row.kind == 'number':
            return float(row.value)
        if row.kind == 'integer':
            return int(row.value)
        if row.kind in ('json', 'list'):
            return json.loads(row.value)
        return row.value
    return {r.key: unpack(r) for r in rows if r.key not in ('ingest_secret', 'source_database_url')}
