import hashlib
import hmac
import json
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from .models import Activity, Bot, Customer, Deal, Identity, IngestEvent, Order, Payment, Pipeline, Stage, Ticket

router = APIRouter(prefix='/api/v1')
TYPES = {'customer.upsert', 'customer.activity', 'order.upsert', 'payment.upsert', 'customer.consent', 'customer.blocked','lead.upsert','ticket.upsert'}


def money(value):
    try:
        amount = Decimal(str(value))
        if not amount.is_finite() or amount < 0 or amount.as_tuple().exponent < -2 or amount > Decimal('999999999999.99'):
            raise ValueError()
        return amount
    except (InvalidOperation, ValueError):
        raise HTTPException(422, 'Invalid monetary amount')


def field(value, max_length=200, required=False):
    if value is None:
        value = ''
    if not isinstance(value, str) or len(value) > max_length or (required and not value.strip()):
        raise HTTPException(422, 'Invalid event field')
    return value.strip()


@router.post('/events')
async def receive_event(request: Request):
    raw = await request.body()
    if len(raw) > 65536:
        raise HTTPException(413, 'Event too large')
    key = request.headers.get('X-Bot-Key', '')
    secret = request.app.state.settings.ingest_secrets.get(key)
    stamp = request.headers.get('X-Timestamp', '')
    try:
        timestamp = int(stamp)
    except ValueError:
        raise HTTPException(401, 'Invalid signature')
    signature = request.headers.get('X-Signature', '')
    expected = hmac.new(secret.encode() if secret else b'', stamp.encode() + b'.' + raw, hashlib.sha256).hexdigest()
    if not secret or len(secret) < 24 or abs(time.time() - timestamp) > 300 or not hmac.compare_digest(signature, expected):
        raise HTTPException(401, 'Invalid signature')
    try:
        payload = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(422, 'Invalid JSON')
    if not isinstance(payload, dict) or payload.get('type') not in TYPES or not isinstance(payload.get('data'), dict):
        raise HTTPException(422, 'Invalid event')
    event_id = field(payload.get('event_id'), 120, True)
    external_user_id = field(payload['data'].get('external_user_id'), 100, True)
    data = payload['data']
    factory = request.app.state.session_factory
    with factory() as db:
        bot = db.scalar(select(Bot).where(Bot.key == key, Bot.active.is_(True)))
        if not bot:
            raise HTTPException(404, 'Unknown bot')
        if db.scalar(select(IngestEvent).where(IngestEvent.bot_id == bot.id, IngestEvent.event_id == event_id)):
            return {'ok': True, 'duplicate': True}
        identity = db.scalar(select(Identity).where(Identity.bot_id == bot.id, Identity.external_user_id == external_user_id))
        if not identity:
            # Identity is bot-scoped: no automatic cross-bot merge by phone/email.
            customer = Customer(source=key)
            db.add(customer)
            db.flush()
            identity = Identity(bot_id=bot.id, customer_id=customer.id, external_user_id=external_user_id)
            db.add(identity)
        else:
            customer = db.get(Customer, identity.customer_id)
        if 'name' in data:
            customer.name = field(data['name'], 200)
        if 'email' in data:
            customer.email = field(data['email'], 255) or None
        if 'phone' in data:
            customer.phone = field(data['phone'], 40) or None
        if 'language' in data:
            customer.language = field(data['language'], 10) or 'ru'
        if 'chat_id' in data:
            identity.chat_id = field(str(data['chat_id']), 100) or None
        if 'blocked' in data and payload['type'] == 'customer.blocked':
            identity.blocked = bool(data['blocked'])
        if payload['type'] == 'customer.consent':
            customer.marketing_consent = data.get('consent') is True
            customer.consent_at = datetime.now(timezone.utc) if customer.marketing_consent else None
        customer.last_seen_at = datetime.now(timezone.utc)
        bot.last_seen_at = customer.last_seen_at
        typ = payload['type']
        if typ == 'customer.activity':
            db.add(Activity(customer_id=customer.id, bot_id=bot.id, kind=field(data.get('kind'), 60, True), summary=field(data.get('summary'), 2000)))
        if typ == 'lead.upsert':
            external_id=field(data.get('external_id'),120,True)
            deal=db.scalar(select(Deal).where(Deal.bot_id==bot.id,Deal.external_id==external_id))
            if not deal:
                pipeline=db.scalar(select(Pipeline).where(Pipeline.active.is_(True)).order_by(Pipeline.id))
                stage=db.scalar(select(Stage).where(Stage.pipeline_id==pipeline.id).order_by(Stage.position)) if pipeline else None
                if not stage:raise HTTPException(409,'Create a CRM sales pipeline first')
                deal=Deal(bot_id=bot.id,external_id=external_id,customer_id=customer.id,
                    pipeline_id=pipeline.id,stage_id=stage.id,source=bot.key)
                db.add(deal)
            elif deal.customer_id!=customer.id:raise HTTPException(409,'Lead belongs to another customer')
            service=field(data.get('service','website'),80,True)
            if service not in {'website','web_app','portal','bot','support','integration','other'}:raise HTTPException(422,'Invalid service')
            deal.title=field(data.get('title'),200,True)
            deal.service=service
            deal.budget=money(data.get('budget','0'))
            deal.currency=field(data.get('currency','UAH'),3,True).upper()
            db.add(Activity(customer_id=customer.id,bot_id=bot.id,kind='lead',summary=deal.title))
        if typ == 'ticket.upsert':
            external_id=field(data.get('external_id'),120,True)
            ticket=db.scalar(select(Ticket).where(Ticket.bot_id==bot.id,Ticket.external_id==external_id))
            if not ticket:
                ticket=Ticket(bot_id=bot.id,external_id=external_id,customer_id=customer.id)
                db.add(ticket)
            elif ticket.customer_id!=customer.id:raise HTTPException(409,'Ticket belongs to another customer')
            ticket.title=field(data.get('title'),200,True)
            ticket.description=field(data.get('description'),5000)
            status=field(data.get('status','open'),20,True)
            if status not in {'open','in_progress','waiting','resolved'}:raise HTTPException(422,'Invalid ticket status')
            ticket.status=status
        if typ == 'order.upsert':
            external_id = field(data.get('external_id'), 120, True)
            order = db.scalar(select(Order).where(Order.bot_id == bot.id, Order.external_id == external_id))
            if not order:
                order = Order(bot_id=bot.id, customer_id=customer.id, external_id=external_id)
                db.add(order)
            elif order.customer_id != customer.id:
                raise HTTPException(409, 'Order belongs to another customer')
            order.title = field(data.get('title'), 200, True)
            order.status = field(data.get('status', 'new'), 30, True)
            order.amount = money(data.get('amount', '0'))
            order.currency = field(data.get('currency', 'UAH'), 3, True).upper()
        if typ == 'payment.upsert':
            external_id = field(data.get('external_id'), 120, True)
            payment = db.scalar(select(Payment).where(Payment.bot_id == bot.id, Payment.external_id == external_id))
            if not payment:
                payment = Payment(bot_id=bot.id, customer_id=customer.id, external_id=external_id)
                db.add(payment)
            elif payment.customer_id != customer.id:
                raise HTTPException(409, 'Payment belongs to another customer')
            payment.status = field(data.get('status', 'pending'), 30, True)
            payment.provider = field(data.get('provider', 'manual'), 80, True)
            payment.amount = money(data.get('amount'))
            payment.currency = field(data.get('currency', 'UAH'), 3, True).upper()
            if data.get('order_external_id'):
                order = db.scalar(select(Order).where(Order.bot_id == bot.id, Order.external_id == field(data['order_external_id'], 120)))
                payment.order_id = order.id if order and order.customer_id == customer.id else None
        db.add(IngestEvent(bot_id=bot.id, event_id=event_id, event_type=typ))
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            if db.scalar(select(IngestEvent).where(IngestEvent.bot_id == bot.id, IngestEvent.event_id == event_id)):
                return {'ok': True, 'duplicate': True}
            raise
        return {'ok': True, 'duplicate': False, 'customer_id': customer.id}
