"""Authenticated, deliberately read-only smartphone views of CRM-owned tables."""
from fastapi import APIRouter, HTTPException, Request
from sqlalchemy import func, select
from . import models as m
from .security import require_admin

router=APIRouter(prefix='/m')

# Strict allowlist. Password hashes, secrets and arbitrary SQL tables are never exposed.
TABLES={
    'customers': ('Клиенты',m.Customer,('name','phone','status'),('id','name','email','phone','language','status','source','tags','notes','marketing_consent','consent_at','last_seen_at','created_at'),'name'),
    'companies': ('Компании',m.Company,('name','industry','status'),('id','name','industry','website','email','phone','status','notes','created_at'),'name'),
    'company_contacts': ('Контакты компаний',m.CompanyContact,('company_id','customer_id','role'),('id','company_id','customer_id','role'),None),
    'bots': ('Боты',m.Bot,('name','key','last_seen_at'),('id','key','name','description','active','last_seen_at','created_at'),'name'),
    'identities': ('Идентификаторы ботов',m.Identity,('external_user_id','bot_id','customer_id'),('id','bot_id','customer_id','external_user_id','chat_id','blocked','created_at'),'external_user_id'),
    'pipelines': ('Воронки',m.Pipeline,('name','active'),('id','name','description','active','created_at'),'name'),
    'stages': ('Стадии сделок',m.Stage,('name','position','probability'),('id','pipeline_id','name','position','probability','terminal'),'name'),
    'deals': ('Сделки',m.Deal,('title','service','budget'),('id','title','customer_id','company_id','pipeline_id','stage_id','service','budget','currency','source','owner_id','expected_close_at','notes','created_at','updated_at'),'title'),
    'projects': ('Веб-проекты',m.Project,('title','service','status'),('id','title','deal_id','customer_id','company_id','service','status','domain','repository_url','budget','currency','starts_at','due_at','launched_at','notes','created_at'),'title'),
    'milestones': ('Этапы проектов',m.Milestone,('title','status','due_at'),('id','project_id','title','position','status','due_at','completed_at','created_at'),'title'),
    'tickets': ('Обращения',m.Ticket,('title','priority','status'),('id','title','customer_id','project_id','kind','priority','status','description','resolved_at','created_at'),'title'),
    'tasks': ('Задачи',m.Task,('title','status','due_at'),('id','title','customer_id','status','due_at','created_at'),'title'),
    'orders': ('Заказы ботов',m.Order,('title','status','amount'),('id','bot_id','customer_id','external_id','title','status','amount','currency','created_at'),'title'),
    'payments': ('Платежи',m.Payment,('external_id','amount','status'),('id','bot_id','order_id','customer_id','external_id','provider','status','amount','currency','created_at'),'external_id'),
    'expenses': ('Расходы',m.Expense,('category','vendor','amount'),('id','bot_id','category','vendor','amount','currency','spent_at','memo','created_at'),'category'),
    'campaigns': ('Рассылки',m.Campaign,('title','status','bot_id'),('id','bot_id','title','message','tag_filter','status','created_by','created_at'),'title'),
    'deliveries': ('Доставки',m.Delivery,('campaign_id','status','attempts'),('id','campaign_id','identity_id','status','attempts','next_attempt_at','telegram_message_id','error','created_at'),None),
    'activities': ('История событий',m.Activity,('kind','summary','customer_id'),('id','customer_id','bot_id','kind','summary','created_at'),'summary'),
    'ingest_events': ('Входящие события',m.IngestEvent,('event_type','event_id','bot_id'),('id','bot_id','event_id','event_type','created_at'),'event_id'),
    'audit': ('Аудит действий',m.Audit,('action','target','created_at'),('id','admin_id','action','target','detail','created_at'),'action'),
    'admins': ('Администраторы',m.Admin,('email','role','active'),('id','email','role','active','created_at'),'email'),
}

LABELS={'id':'№ записи','name':'Имя / название','title':'Название','status':'Статус','created_at':'Создано',
    'updated_at':'Изменено','customer_id':'Клиент','company_id':'Компания','bot_id':'Бот','deal_id':'Сделка',
    'project_id':'Проект','pipeline_id':'Воронка','stage_id':'Стадия','campaign_id':'Рассылка','identity_id':'Аккаунт бота',
    'admin_id':'Администратор','owner_id':'Ответственный','order_id':'Заказ','email':'Email','phone':'Телефон',
    'language':'Язык','source':'Источник','tags':'Теги','notes':'Заметки','marketing_consent':'Согласие на рассылку',
    'consent_at':'Дата согласия','last_seen_at':'Последний сигнал','website':'Сайт','industry':'Отрасль',
    'role':'Роль','key':'Ключ','description':'Описание','active':'Активен','external_user_id':'Telegram ID',
    'chat_id':'Чат ID','blocked':'Блокирован','position':'Порядок','probability':'Вероятность, %',
    'terminal':'Финальная стадия','service':'Услуга','budget':'Бюджет','currency':'Валюта',
    'expected_close_at':'Ожидаемая дата','domain':'Домен','repository_url':'Репозиторий','starts_at':'Начало',
    'due_at':'Срок','launched_at':'Дата запуска','completed_at':'Завершено','kind':'Тип','priority':'Приоритет',
    'resolved_at':'Решено','external_id':'Внешний ID','amount':'Сумма','provider':'Платежный сервис',
    'category':'Категория','vendor':'Поставщик','spent_at':'Дата расхода','memo':'Комментарий',
    'message':'Сообщение','tag_filter':'Фильтр по тегу','created_by':'Автор','attempts':'Попытки',
    'next_attempt_at':'Следующая попытка','telegram_message_id':'Telegram сообщение','error':'Ошибка',
    'summary':'Содержание','event_id':'ID события','event_type':'Тип события','action':'Действие','target':'Объект','detail':'Детали'}
LINKS={'customer_id':'customers','company_id':'companies','bot_id':'bots','deal_id':'deals','project_id':'projects',
       'pipeline_id':'pipelines','stage_id':'stages','campaign_id':'campaigns','identity_id':'identities',
       'admin_id':'admins','owner_id':'admins','order_id':'orders'}
OWNER_ONLY={'admins','audit','ingest_events'}
GROUPS=[('Продажи',['customers','companies','company_contacts','pipelines','stages','deals']),
        ('Разработка',['projects','milestones','tickets','tasks']),
        ('Финансы',['orders','payments','expenses']),
        ('Боты и сообщения',['bots','identities','campaigns','deliveries','activities']),
        ('Система',['ingest_events','audit','admins'])]


def view(request, name, **data):
    return request.app.state.templates.TemplateResponse(request,name,{'request':request,**data})


def access(request,db,key=None):
    admin=require_admin(request,db)
    if key in OWNER_ONLY and admin.role!='owner': raise HTTPException(403)
    return admin


def fields(row, names):
    result=[]
    for field in names:
        value=getattr(row,field)
        result.append({'key':field,'label':LABELS.get(field,field.replace('_',' ')),
            'value':value,'href':f"/m/t/{LINKS[field]}/{value}" if field in LINKS and value is not None else None})
    return result


@router.get('')
@router.get('/')
def mobile_home(request:Request):
    with request.app.state.session_factory() as db:
        admin=access(request,db)
        summaries={key:db.scalar(select(func.count()).select_from(model)) for key,(_,model,_,_,_) in TABLES.items() if key not in OWNER_ONLY or admin.role=='owner'}
        return view(request,'mobile/home.html',admin=admin,groups=GROUPS,tables=TABLES,counts=summaries,
                    recent=db.scalars(select(m.Project).order_by(m.Project.id.desc()).limit(3)).all())


@router.get('/t/{key}')
def mobile_table(request:Request,key:str,q:str='',page_no:int=1):
    table=TABLES.get(key)
    if table is None: raise HTTPException(404)
    label,model,summary,detail,search=table
    with request.app.state.session_factory() as db:
        admin=access(request,db,key)
        stmt=select(model)
        if search and q.strip(): stmt=stmt.where(getattr(model,search).ilike('%'+q.strip()[:100]+'%'))
        page_no=max(1,min(page_no,100000))
        total=db.scalar(select(func.count()).select_from(stmt.subquery()))
        rows=db.scalars(stmt.order_by(model.id.desc()).offset((page_no-1)*20).limit(20)).all()
        cards=[{'id':r.id,'fields':fields(r,summary)} for r in rows]
        return view(request,'mobile/table.html',admin=admin,key=key,label=label,total=total,cards=cards,
                    q=q,searchable=bool(search),page_no=page_no)


@router.get('/t/{key}/{row_id}')
def mobile_detail(request:Request,key:str,row_id:int):
    table=TABLES.get(key)
    if table is None: raise HTTPException(404)
    label,model,summary,detail,search=table
    with request.app.state.session_factory() as db:
        admin=access(request,db,key)
        row=db.get(model,row_id)
        if row is None: raise HTTPException(404)
        return view(request,'mobile/detail.html',admin=admin,key=key,label=label,row_id=row_id,items=fields(row,detail))
