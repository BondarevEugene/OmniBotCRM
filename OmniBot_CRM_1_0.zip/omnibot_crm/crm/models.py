from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base


def now():
    return datetime.now(timezone.utc)


class Stamp:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, nullable=False)


class Admin(Stamp, Base):
    __tablename__ = 'crm_admins'
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default='owner')
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Bot(Stamp, Base):
    __tablename__ = 'crm_bots'
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(Text, default='')
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Customer(Stamp, Base):
    __tablename__ = 'crm_customers'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), default='')
    email: Mapped[str | None] = mapped_column(String(255), index=True)
    phone: Mapped[str | None] = mapped_column(String(40), index=True)
    language: Mapped[str] = mapped_column(String(10), default='ru')
    status: Mapped[str] = mapped_column(String(30), default='lead')
    source: Mapped[str] = mapped_column(String(120), default='manual')
    tags: Mapped[str] = mapped_column(String(500), default='')
    notes: Mapped[str] = mapped_column(Text, default='')
    marketing_consent: Mapped[bool] = mapped_column(Boolean, default=False)
    consent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    identities: Mapped[list['Identity']] = relationship(back_populates='customer')


class Identity(Stamp, Base):
    __tablename__ = 'crm_identities'
    __table_args__ = (UniqueConstraint('bot_id', 'external_user_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int] = mapped_column(ForeignKey('crm_bots.id'), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey('crm_customers.id'), index=True)
    external_user_id: Mapped[str] = mapped_column(String(100))
    chat_id: Mapped[str | None] = mapped_column(String(100))
    blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    customer: Mapped[Customer] = relationship(back_populates='identities')
    bot: Mapped[Bot] = relationship()


class Activity(Stamp, Base):
    __tablename__ = 'crm_activities'
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey('crm_customers.id'), index=True)
    bot_id: Mapped[int | None] = mapped_column(ForeignKey('crm_bots.id'))
    kind: Mapped[str] = mapped_column(String(60))
    summary: Mapped[str] = mapped_column(Text, default='')


class Order(Stamp, Base):
    __tablename__ = 'crm_orders'
    __table_args__ = (UniqueConstraint('bot_id', 'external_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int] = mapped_column(ForeignKey('crm_bots.id'), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey('crm_customers.id'), index=True)
    external_id: Mapped[str] = mapped_column(String(120))
    title: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(30), default='new')
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=0)
    currency: Mapped[str] = mapped_column(String(3), default='UAH')
    customer: Mapped[Customer] = relationship()
    bot: Mapped[Bot] = relationship()


class Payment(Stamp, Base):
    __tablename__ = 'crm_payments'
    __table_args__ = (UniqueConstraint('bot_id', 'external_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int] = mapped_column(ForeignKey('crm_bots.id'), index=True)
    order_id: Mapped[int | None] = mapped_column(ForeignKey('crm_orders.id'), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey('crm_customers.id'), index=True)
    external_id: Mapped[str] = mapped_column(String(120))
    provider: Mapped[str] = mapped_column(String(80), default='manual')
    status: Mapped[str] = mapped_column(String(30), default='pending')
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    currency: Mapped[str] = mapped_column(String(3), default='UAH')
    customer: Mapped[Customer] = relationship()
    bot: Mapped[Bot] = relationship()


class Expense(Stamp, Base):
    __tablename__ = 'crm_expenses'
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int | None] = mapped_column(ForeignKey('crm_bots.id'))
    category: Mapped[str] = mapped_column(String(80))
    vendor: Mapped[str] = mapped_column(String(150), default='')
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    currency: Mapped[str] = mapped_column(String(3), default='UAH')
    spent_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    memo: Mapped[str] = mapped_column(Text, default='')


class Task(Stamp, Base):
    __tablename__ = 'crm_tasks'
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey('crm_customers.id'))
    title: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default='open')
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    customer: Mapped[Customer | None] = relationship()


class Campaign(Stamp, Base):
    __tablename__ = 'crm_campaigns'
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int] = mapped_column(ForeignKey('crm_bots.id'), index=True)
    title: Mapped[str] = mapped_column(String(200))
    message: Mapped[str] = mapped_column(Text)
    tag_filter: Mapped[str] = mapped_column(String(80), default='')
    status: Mapped[str] = mapped_column(String(20), default='draft')
    created_by: Mapped[int] = mapped_column(ForeignKey('crm_admins.id'))
    bot: Mapped[Bot] = relationship()


class Delivery(Stamp, Base):
    __tablename__ = 'crm_deliveries'
    __table_args__ = (UniqueConstraint('campaign_id', 'identity_id'), Index('ix_delivery_work', 'status', 'next_attempt_at'))
    id: Mapped[int] = mapped_column(primary_key=True)
    campaign_id: Mapped[int] = mapped_column(ForeignKey('crm_campaigns.id'), index=True)
    identity_id: Mapped[int] = mapped_column(ForeignKey('crm_identities.id'))
    status: Mapped[str] = mapped_column(String(20), default='queued')
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    telegram_message_id: Mapped[str | None] = mapped_column(String(100))
    error: Mapped[str | None] = mapped_column(Text)
    campaign: Mapped[Campaign] = relationship()
    identity: Mapped[Identity] = relationship()


class IngestEvent(Stamp, Base):
    __tablename__ = 'crm_ingest_events'
    __table_args__ = (UniqueConstraint('bot_id', 'event_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int] = mapped_column(ForeignKey('crm_bots.id'))
    event_id: Mapped[str] = mapped_column(String(120))
    event_type: Mapped[str] = mapped_column(String(50))


class Audit(Stamp, Base):
    __tablename__ = 'crm_audit'
    id: Mapped[int] = mapped_column(primary_key=True)
    admin_id: Mapped[int | None] = mapped_column(ForeignKey('crm_admins.id'))
    action: Mapped[str] = mapped_column(String(120))
    target: Mapped[str] = mapped_column(String(120), default='')
    detail: Mapped[str] = mapped_column(Text, default='')


class Company(Stamp, Base):
    __tablename__ = 'crm_companies'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    website: Mapped[str] = mapped_column(String(255), default='')
    industry: Mapped[str] = mapped_column(String(100), default='')
    email: Mapped[str] = mapped_column(String(255), default='')
    phone: Mapped[str] = mapped_column(String(40), default='')
    notes: Mapped[str] = mapped_column(Text, default='')
    status: Mapped[str] = mapped_column(String(30), default='prospect')


class CompanyContact(Base):
    __tablename__ = 'crm_company_contacts'
    __table_args__ = (UniqueConstraint('company_id','customer_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    company_id: Mapped[int] = mapped_column(ForeignKey('crm_companies.id'), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey('crm_customers.id'), index=True)
    role: Mapped[str] = mapped_column(String(100), default='contact')
    company: Mapped[Company] = relationship()
    customer: Mapped[Customer] = relationship()


class Pipeline(Stamp, Base):
    __tablename__ = 'crm_pipelines'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    description: Mapped[str] = mapped_column(Text, default='')
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Stage(Base):
    __tablename__ = 'crm_stages'
    __table_args__ = (UniqueConstraint('pipeline_id','position'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    pipeline_id: Mapped[int] = mapped_column(ForeignKey('crm_pipelines.id'), index=True)
    name: Mapped[str] = mapped_column(String(100))
    position: Mapped[int] = mapped_column(Integer)
    probability: Mapped[int] = mapped_column(Integer, default=0)
    terminal: Mapped[str] = mapped_column(String(10), default='')  # '', 'won', 'lost'
    pipeline: Mapped[Pipeline] = relationship()


class Deal(Stamp, Base):
    __tablename__ = 'crm_deals'
    __table_args__ = (UniqueConstraint('bot_id','external_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int | None] = mapped_column(ForeignKey('crm_bots.id'), index=True)
    external_id: Mapped[str | None] = mapped_column(String(120))
    title: Mapped[str] = mapped_column(String(200))
    customer_id: Mapped[int | None] = mapped_column(ForeignKey('crm_customers.id'), index=True)
    company_id: Mapped[int | None] = mapped_column(ForeignKey('crm_companies.id'), index=True)
    pipeline_id: Mapped[int] = mapped_column(ForeignKey('crm_pipelines.id'), index=True)
    stage_id: Mapped[int] = mapped_column(ForeignKey('crm_stages.id'), index=True)
    service: Mapped[str] = mapped_column(String(80), default='website')
    budget: Mapped[Decimal] = mapped_column(Numeric(14,2), default=0)
    currency: Mapped[str] = mapped_column(String(3), default='UAH')
    source: Mapped[str] = mapped_column(String(120), default='manual')
    owner_id: Mapped[int | None] = mapped_column(ForeignKey('crm_admins.id'))
    expected_close_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str] = mapped_column(Text, default='')
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)
    customer: Mapped[Customer | None] = relationship()
    company: Mapped[Company | None] = relationship()
    pipeline: Mapped[Pipeline] = relationship()
    stage: Mapped[Stage] = relationship()


class Project(Stamp, Base):
    __tablename__ = 'crm_projects'
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    deal_id: Mapped[int | None] = mapped_column(ForeignKey('crm_deals.id'), index=True)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey('crm_customers.id'))
    company_id: Mapped[int | None] = mapped_column(ForeignKey('crm_companies.id'))
    service: Mapped[str] = mapped_column(String(80), default='website')
    status: Mapped[str] = mapped_column(String(30), default='discovery')
    domain: Mapped[str] = mapped_column(String(255), default='')
    repository_url: Mapped[str] = mapped_column(String(500), default='')
    budget: Mapped[Decimal] = mapped_column(Numeric(14,2), default=0)
    currency: Mapped[str] = mapped_column(String(3), default='UAH')
    starts_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    launched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str] = mapped_column(Text, default='')
    customer: Mapped[Customer | None] = relationship()
    company: Mapped[Company | None] = relationship()
    deal: Mapped[Deal | None] = relationship()


class Milestone(Stamp, Base):
    __tablename__ = 'crm_milestones'
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey('crm_projects.id'), index=True)
    title: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default='planned')
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    position: Mapped[int] = mapped_column(Integer, default=0)
    project: Mapped[Project] = relationship()


class Ticket(Stamp, Base):
    __tablename__ = 'crm_tickets'
    __table_args__ = (UniqueConstraint('bot_id','external_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bot_id: Mapped[int | None] = mapped_column(ForeignKey('crm_bots.id'), index=True)
    external_id: Mapped[str | None] = mapped_column(String(120))
    title: Mapped[str] = mapped_column(String(200))
    customer_id: Mapped[int | None] = mapped_column(ForeignKey('crm_customers.id'))
    project_id: Mapped[int | None] = mapped_column(ForeignKey('crm_projects.id'))
    kind: Mapped[str] = mapped_column(String(30), default='support')
    priority: Mapped[str] = mapped_column(String(20), default='normal')
    status: Mapped[str] = mapped_column(String(20), default='open')
    description: Mapped[str] = mapped_column(Text, default='')
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    customer: Mapped[Customer | None] = relationship()
    project: Mapped[Project | None] = relationship()
