from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from .config import Settings, settings
from .db import make_session_factory
from .ingest import router as ingest_router
from .web import router as web_router
from .workflows import router as workflows_router
from .mobile import router as mobile_router


def create_app(config: Settings | None = None) -> FastAPI:
    config = config or settings()
    config.validate()
    engine, factory = make_session_factory(config.database_url)
    app = FastAPI(title='OmniBot CRM', version='1.0.0', docs_url=None, redoc_url=None)
    app.state.settings = config
    app.state.engine = engine
    app.state.session_factory = factory
    root = Path(__file__).parent
    app.state.templates = Jinja2Templates(directory=root / 'templates')
    app.add_middleware(SessionMiddleware, secret_key=config.session_secret, https_only=config.cookie_secure, same_site='lax', max_age=28800)
    app.mount('/static', StaticFiles(directory=root / 'static'), name='static')
    app.include_router(ingest_router)
    app.include_router(web_router)
    app.include_router(workflows_router)
    app.include_router(mobile_router)

    @app.get('/health/live')
    def live(): return {'status': 'up'}

    @app.get('/health/ready')
    def ready():
        from sqlalchemy import text
        try:
            with engine.connect() as connection: connection.execute(text('SELECT 1'))
            return {'status': 'ready'}
        except Exception:
            return JSONResponse({'status':'unavailable'}, status_code=503)

    return app


app = create_app()
