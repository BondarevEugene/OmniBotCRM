"""Run exactly one worker replica for predictable Telegram pacing."""
import argparse
import logging
import time
from datetime import datetime, timedelta, timezone
import httpx
from sqlalchemy import func, select, update
from sqlalchemy.orm import selectinload
from .config import settings
from .db import make_session_factory
from .models import Campaign, Customer, Delivery, Identity

log=logging.getLogger(__name__)


def utc(): return datetime.now(timezone.utc)


def process_one(factory, tokens, client):
    with factory() as db:
        # Stale processing rows are marked unknown: Telegram may have delivered a request
        # before our process died, so automatic re-sending might duplicate it.
        db.execute(update(Delivery).where(Delivery.status=='processing',Delivery.next_attempt_at<utc()).values(status='unknown',error='Delivery outcome unknown; review manually'))
        row=db.scalar(select(Delivery).join(Campaign).where(Delivery.status=='queued',Delivery.next_attempt_at<=utc(),Campaign.status.in_(['queued','running'])).order_by(Delivery.id).with_for_update(skip_locked=True).limit(1))
        if not row:
            db.commit(); return False
        campaign=db.get(Campaign,row.campaign_id)
        identity=db.get(Identity,row.identity_id)
        customer=db.get(Customer,identity.customer_id)
        if not customer.marketing_consent or customer.status=='blocked' or identity.blocked or not identity.chat_id:
            row.status='skipped'; row.error='Consent revoked or chat unavailable'; db.commit(); return True
        token=tokens.get(campaign.bot.key)
        if not token:
            row.status='failed'; row.error='Missing bot token'; db.commit(); return True
        row.status='processing'; row.attempts+=1; row.next_attempt_at=utc()+timedelta(minutes=5)
        campaign.status='running'
        db.commit()
        delivery_id=row.id
        chat_id=identity.chat_id
        message=campaign.message
    try:
        response=client.post(f'https://api.telegram.org/bot{token}/sendMessage',json={'chat_id':chat_id,'text':message,'disable_web_page_preview':True},timeout=15)
        result=response.json()
    except (httpx.RequestError,ValueError) as exc:
        # Unknown outcome, do not retry automatically.
        with factory() as db:
            row=db.get(Delivery,delivery_id); row.status='unknown'; row.error=str(exc)[:400]; db.commit()
        return True
    with factory() as db:
        row=db.get(Delivery,delivery_id)
        if result.get('ok'):
            row.status='sent'; row.telegram_message_id=str(result['result']['message_id']); row.error=None
        elif response.status_code==429 and row.attempts<5:
            retry=max(1,min(3600,int(result.get('parameters',{}).get('retry_after',30))))
            row.status='queued'; row.next_attempt_at=utc()+timedelta(seconds=retry); row.error='Rate limited'
        else:
            row.status='failed'; row.error=str(result.get('description','Telegram error'))[:400]
            if response.status_code==403:
                identity=db.get(Identity,row.identity_id); identity.blocked=True
        db.commit()
    return True


def close_finished(factory):
    with factory() as db:
        active=db.scalars(select(Campaign).where(Campaign.status.in_(['queued','running']))).all()
        for campaign in active:
            pending=db.scalar(select(func.count()).select_from(Delivery).where(Delivery.campaign_id==campaign.id,Delivery.status.in_(['queued','processing'])))
            if pending==0: campaign.status='completed'
        db.commit()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--once',action='store_true')
    args=parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    config=settings(); engine,factory=make_session_factory(config.database_url)
    try:
        with httpx.Client() as client:
            while True:
                worked=process_one(factory,config.bot_tokens,client)
                close_finished(factory)
                if args.once: break
                time.sleep(.15 if worked else 2)
    finally: engine.dispose()


if __name__=='__main__': main()
