"""Import existing Food_Porn customers and menus without touching its tables.

Example: python -m integrations.food_porn_import --source-url "$FOOD_PORN_DATABASE_URL"
"""
import argparse
from sqlalchemy import create_engine, select, text
from sqlalchemy.orm import Session
from crm.config import settings
from crm.db import make_session_factory
from crm.models import Bot, Customer, Identity, Order


def import_data(source_url: str, target_url: str, *, dry_run=False):
    source_url=source_url.replace('postgresql+asyncpg://','postgresql+psycopg://',1)
    source=create_engine(source_url,pool_pre_ping=True)
    target,factory=make_session_factory(target_url)
    customers=orders=0
    try:
        with source.connect() as old, factory() as db:
            bot=db.scalar(select(Bot).where(Bot.key=='food_porn'))
            if bot is None: raise RuntimeError('Register bot key food_porn before import')
            for row in old.execute(text('SELECT id, telegram_user_id, name, phone, language, last_seen_at FROM customers ORDER BY id')).mappings():
                identity=db.scalar(select(Identity).where(Identity.bot_id==bot.id,Identity.external_user_id==str(row['telegram_user_id'])))
                if identity is None:
                    customer=Customer(name=row['name'] or '',phone=row['phone'] or None,language=str(row['language']).lower()[:10],source='food_porn',last_seen_at=row['last_seen_at'])
                    db.add(customer); db.flush()
                    identity=Identity(bot_id=bot.id,customer_id=customer.id,external_user_id=str(row['telegram_user_id']),chat_id=str(row['telegram_user_id']))
                    db.add(identity)
                else:
                    customer=db.get(Customer,identity.customer_id)
                customers+=1
                for menu in old.execute(text('SELECT id, status, is_paid FROM menus WHERE customer_id=:id'),{'id':row['id']}).mappings():
                    external_id=str(menu['id'])
                    order=db.scalar(select(Order).where(Order.bot_id==bot.id,Order.external_id==external_id))
                    if order is None:
                        db.add(Order(bot_id=bot.id,customer_id=customer.id,external_id=external_id,title=f'Меню #{external_id}',status=str(menu['status']).lower(),amount=0,currency='UAH'))
                    orders+=1
            if dry_run: db.rollback()
            else: db.commit()
        return customers,orders
    finally:
        source.dispose(); target.dispose()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-url',required=True)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    result=import_data(args.source_url,settings().database_url,dry_run=args.dry_run)
    print(f'Customers scanned: {result[0]}, menus scanned: {result[1]}; dry_run={args.dry_run}')
